from  django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('linegroup','plctag','linemsg','linetoken')
        labels = {
            'linegroup' : 'Line Group',
            'plctag' : 'PLC Tag',
            'linemsg' : 'Line Message',
            'linetoken' : 'LineToken'
        }