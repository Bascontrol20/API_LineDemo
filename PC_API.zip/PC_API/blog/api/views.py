from django.shortcuts import render,redirect
from django.http import HttpResponse,Http404
from .models import Post
from .forms import PostForm
from .serializers import PostSerializer

from rest_framework import status,permissions
from rest_framework.views import APIView
from rest_framework.response import Response

''' *****************MAIN PAGE SECTION******************* '''
def msg_list(request):
    #Get lineToken and message all from database
    # linemsg = Linemessage.objects.all()
    context = {'line_list':Post.objects.all()}
    return render(request,"msg_list.html",context)

def msg_form(request,id=0):
    if request.method == "GET":
        if id==0:
            form = PostForm()
        else:
            employee = Post.objects.get(pk=id) 
            form = PostForm(instance=employee)
        return render(request,"msg_form.html",{'form':form})
    else:
        if id==0:
            form = PostForm(request.POST)
        else:
            employee = Post.objects.get(pk=id) 
            form = PostForm(request.POST,instance=employee)
        if form.is_valid():
            form.save()
        return redirect('/')
    

def msg_delete(request,id):
    delete_msg = Post.objects.get(pk=id)
    delete_msg.delete()
    return redirect('/')

''' *****************API SECTION******************* '''

class PostList(APIView):
    
    
    def get(self,request):
        posts = Post.objects.all()
        serializer = PostSerializer(posts,many=True)
        return Response(serializer.data)
        
    def post(self,request):
        serializer = PostSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
    
class  PostDetial(APIView):

    '''Read update or delete an individual post'''

    def get_post(self,pk):
        try:
            return Post.objects.get(pk=pk)
        except :
            raise  Http404

    def get(self,request,pk):
        post = self.get_post(pk)
        serializer = PostSerializer(post)
        return Response(serializer.data)

    def put(self,request,pk):
        post = self.get_post(pk)
        serializer = PostSerializer(post,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

    def delete(self,request,pk):
        post = self.get_post(pk)
        post.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
