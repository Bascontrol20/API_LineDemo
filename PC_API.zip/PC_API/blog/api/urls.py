from django.urls import path,include
from . import views
urlpatterns = [
    
    path('api/', views.PostList.as_view()), 
    path('api/<int:pk>', views.PostDetial.as_view()),
    path('', views.msg_list,name = 'msg_list'),
    path('<int:id>/',views.msg_form,name='msg_update'),
    path('delete/<int:id>/',views.msg_delete,name='msg_delete'),
    path('insert',views.msg_form,name='msg_insert')
]